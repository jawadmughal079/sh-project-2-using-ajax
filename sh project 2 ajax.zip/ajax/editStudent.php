<?php
include 'database.php';
// die()

if (isset($_POST['stundentId'])) {
    $stundentId = $_POST['stundentId'];
    $query = "SELECT * from studentform where stundentId = $stundentId";

    $result = mysqli_query($connection, $query);

    $output = '';

    if (mysqli_num_rows($result) > 0) {


        //  // <th scope="col">Images</th>
        //     <td>{$rows["fileUpload"]}</td>
        // $output .= "
        // <div class='row mt-3'>
        //     <div class='col-6'>
        //         <label for='firstName' class='form-label'>First Name </label>
        //         <input type='text' class='form-control' placeholder='First name' aria-label='First name' name='firstName' id='firstName' value='{$rows["firstName"]}'>
        //     </div>
        // </div>";

        // $output .=  '<div class="row mt-3">';
        // $output .=  '<div class="col-md-12 ">';
        // $output .=  '<label for="email" class="form-label">Email <span class="text-danger fw-bold text-center"> * </span></label>';
        // $output .=  '';
        // $output .=  '<input type="text" class="form-control" placeholder="Enter Your Email" name="email" id="email" value="' . $rows['email'] . '">';
        // $output .=  '';
        // $output .=  '</div>';
        // $output .=  '';
        // $output .=  '</div>';

        // $output .=  '<div class="row mt-3">';
        // $output .=  '<div class="col-md-6">';
        // $output .=  '<label for="degree" class="form-label">Degree <span class="text-danger fw-bold text-center"> * </span></label>';
        // $output .=  '';
        // $output .=  '<select class="form-select" name="degree" id="degree">';
        // $output .=  '<option selected disabled value="">Choose Your Degree...</option>';
        // $output .=  '<option value="bsse" if(' . $rows['degree'] . ' == "bsse"){ $output .=  "selected";}>Bsse</option>';
        // $output .=  '<option value="bscs" if(' . $rows['degree'] . ' == "bscs"){ $output .=  "selected";}>bscs</option>';
        // $output .=  '</select>';
        // $output .=  '';
        // $output .=  '</div>';
        // $output .=  '<div class="col-md-6">';
        // $output .=  '<label for="fees" class="form-label">Fees <span class="text-danger fw-bold text-center"> * </span></label>';
        // $output .=  '';
        // $output .=  '<select id="fees" class="form-select" name="fees" value="">';
        // $output .=  '<option selected disabled value="">Choose Your Fees...</option>';
        // $output .=  '<option value="5000">5000</option>';
        // $output .=  '<option value="10000">10000</option>';
        // $output .=  '</select>';
        // $output .=  '';
        // $output .=  '</div>';
        // $output .=  '';
        // $output .=  '</div>';

        // $output .=  '<div class="row mt-3">';
        // $output .=  '<div class="col-md-6">';
        // $output .=  '<label for="exampleInputEmail1" class="form-label">Degree</label>';
        // $output .=  '';
        // $output .=  '<select id="inputState" class="form-select" name="degree">';
        // $output .=  '<option selected disabled>Choose Your Degree...</option>';
        // $output .=  '';
        // $output .=  '<option value="bsse"  if ($rows[' . "degree" . '] == "bsse") {$output .=  ' . "selected" . ';} >bsse</option>';
        // $output .=  '<option value="bscs"  if ($rows[' . "degree" . '] == "bscs") {$output .=  ' . "selected" . ';} > bscs</option>';
        // $output .=  '';
        // $output .=  '</select>';
        // $output .=  '</div>';
        // $output .=  '<label for="exampleInputEmail1" class="form-label">Fees</label>';
        // $output .=  '';
        // $output .=  '<select id="inputState" class="form-select" name="fees">';
        // $output .=  '<option value="1000" if ($rows[' . "fees" . '] == "10000") {$output .=  ' . "selected" . ';} >10000</option>';
        // $output .=  '<option value="5000" if ($rows[' . "fees" . '] == "5000") {$output .=  ' . "selected" . ';} > 5000</option>';
        // $output .=  '</select>';
        // $output .=  '</div>';
        // $output .=  '';
        // $output .=  '</div>';
        // $output .=  '<div class="row mt-6">';
        // $output .=  '';
        // $output .=  '<div class="col-md-6">';
        // $output .=  '';
        // $output .=  '<label for="exampleInputEmail1" class="form-label mt-4">Gender</label>';
        // $output .=  '<div class="form-check form-check-inline">';
        // $output .=  '<input class="form-check-input" type="radio" name="gender" class="gender" value="male" if ($rows[' . "gender" . '] == ' . "male" . ') {$output .=  ' . "checked" . ';} >';
        // $output .=  '<label class="form-check-label" for="inlineRadio1">Male</label>';
        // $output .=  '</div>';
        // $output .=  '<div class="form-check form-check-inline">';
        // $output .=  '<input class="form-check-input" type="radio" name="gender" class="gender" value="female"  if ($rows[' . "gender" . '] == ' . "female" . ') {$output .=  ' . "checked" . ';} >';
        // $output .=  '<label class="form-check-label" for="inlineRadio2">Female</label>';
        // $output .=  '</div>';
        //      '</div>';
        while ($rows = mysqli_fetch_assoc($result)) {

            $output .=  '<div class="row mt-3">';
            $output .=  '<div class="col-6">';
            $output .=  '<label for="firstName" class="form-label">First Name</label>';
            $output .=  '<input type="text" class="form-control"  placeholder="First name" aria-label="First name" name="firstName" id="updateFirstName" value=" ' . $rows["firstName"] . '">';
            $output .=  '<input type="text" class="form-control" id="stundentId" hidden placeholder="First name" aria-label="First name" name="stundentId" value=" ' . $rows["stundentId"] . '">';
            $output .=  '</div>';
            $output .=  '<div class="col-6">';
            $output .=  '<label for="exampleInputEmail1" class="form-label">Last Name</label>';
            $output .=  '';
            $output .=  '<input type="text" class="form-control" placeholder="Last name" aria-label="Last name" id="updateLastName" name="lastName" value="' . $rows['lastName'] . '">';
            $output .=  '</div>';
            $output .=  '';
            $output .=  '</div>';
            $output .=  '<div class="row mt-3">';
            $output .=  '<div class="col-md-12 ">';
            $output .=  '<label for="exampleInputEmail1" class="form-label">Email</label>';
            $output .=  '';
            $output .=  '<input type="email" class="form-control" id="updateEmail" placeholder="Enter Your Email" name="email" value="' . $rows["email"] . '">';
            $output .=  '</div>';
            $output .=  '</div>';

            $output .=  '<div class="row mt-3">';
            $output .=  '<div class="col-md-6">';
            $output .=  '<label for="degree" class="form-label">Degree <span class="text-danger fw-bold text-center"> * </span></label>';
            $output .=  '';
            $output .=  '<select class="form-select" name="degree" id="updateDegree">';
            $output .=  '<option selected disabled value="">Choose Your Degree...</option>';


            $output .=  '<option value="' . $rows['degree'] . '" ' . (($rows['degree'] == 'bsse') ? 'selected="selected"' : "") . '>' . $rows['degree'] . '</option>';
            $output .=  '<option value="' . $rows['degree'] . '" ' . (($rows['degree'] == 'bscs') ? 'selected="selected"' : "") . '>' . $rows['degree'] . '</option>';
            $output .=  '</select>';
            $output .=  '';
            $output .=  '</div>';
            $output .=  '<div class="col-md-6">';
            $output .=  '<label for="fees" class="form-label">Fees <span class="text-danger fw-bold text-center"> * </span></label>';
            $output .=  '';
            $output .=  '<select id="updateFees" class="form-select" name="fees" value="">';
            $output .=  '<option selected disabled value="">Choose Your Fees...</option>';
            $output .=  '<option value="' . $rows['fees'] . '" ' . (($rows['fees'] == 10000) ? 'selected="selected"' : "") . '>' . $rows['fees'] . '</option>';
            $output .=  '<option value="' . $rows['fees'] . '" ' . (($rows['fees'] == 5000) ? 'selected="selected"' : "") . '>' . $rows['fees'] . '</option>';
            $output .=  '</select>';
            $output .=  '';
            $output .=  '</div>';
            $output .=  '';
            $output .=  '</div>';

            $output .=  '<div class="row mt-3">';
            $output .=  '<div class="col-md-12">';
            $output .=  '';
            $output .=  '<label for="exampleInputEmail1" class="form-label mt-4">Gender <span class="text-danger fw-bold text-center"> * </span></label>';
            $output .=  '<div class="form-check form-check-inline">';
            $output .=  '<input class="form-check-input" type="radio" name="gender" class="Updategender" value="' . $rows['gender'] . '" ' . (($rows['gender'] == 'male') ? 'checked="checked"' : "") . '>';
            $output .=  '<label class="form-check-label" for="inlineRadio1">' . $rows['gender'] . '</label>';
            $output .=  '</div>';
            $output .=  '<div class="form-check form-check-inline">';
            $output .=  '<input class="form-check-input" type="radio" name="gender" class="Updategender" value="' . $rows['gender'] . '" ' . (($rows['gender'] == 'female') ? 'checked="checked"' : "") . '>';
            $output .=  '<label class="form-check-label" for="inlineRadio1">' . $rows['gender'] . '</label>';
            $output .=  '</div>';
            $output .=  '</div>';

            // check box

            $array = explode(',', $rows['hobby']);
            $output .=  '<div class="row mt-3 ">';
            $output .=  '<div class="col-md mr-auto">';
            $output .=  '';
            $output .=  '<div class="form-check form-check-inline">';
            $output .=  '<input class="form-check-input" type="checkbox" name="hobby" class="hobby" value="cricket" ' . (in_array("cricket", $array) ? 'checked="checked"' : "") . ' >';
            $output .=  '<label class="form-check-label" for="inlineRadio1">cricket</label>';
            $output .=  '</div>';
            $output .=  '<div class="form-check form-check-inline">';
            $output .=  '<input class="form-check-input" type="checkbox" name="hobby" class="hobby" value="swimming" ' . (in_array("swimming", $array) ? 'checked="checked"' : "") . ' >';
            $output .=  '<label class="form-check-label" for="inlineRadio1">swimming</label>';
            $output .=  '</div>';
            $output .=  '<div class="form-check form-check-inline">';
            $output .=  '<input class="form-check-input" type="checkbox" name="hobby" class="hobby" value="swimming" ' . (in_array("cycling", $array) ? 'checked="checked"' : "") . ' >';
            $output .=  '<label class="form-check-label" for="inlineRadio1">cycling</label>';
            $output .=  '</div>';
            $output .=  '<div class="form-check form-check-inline">';
            $output .=  '<input class="form-check-input" type="checkbox" name="hobby" class="hobby" value="tennis" ' . (in_array("tennis", $array) ? 'checked="checked"' : "") . ' >';
            $output .=  '<label class="form-check-label" for="inlineRadio1">tennis</label>';
            $output .=  '</div>';
            $output .=  '<div class="form-check form-check-inline">';
            $output .=  '<input class="form-check-input" type="checkbox" name="hobby" class="hobby" value="boxing" ' . (in_array("boxing", $array) ? 'checked="checked"' : "") . ' >';
            $output .=  '<label class="form-check-label" for="inlineRadio1">boxing</label>';
            $output .=  '</div>';

            $output .=  '<div class="form-check form-check-inline">';
            $output .=  '<input class="form-check-input" type="checkbox" name="hobby" class="hobby" value="shooting" ' . (in_array("shooting", $array) ? 'checked="checked"' : "") . ' >';
            $output .=  '<label class="form-check-label" for="inlineRadio1">shooting</label>';
            $output .=  '</div>';

            $output .=  '<div class="form-check form-check-inline">';
            $output .=  '<input class="form-check-input" type="checkbox" name="hobby" class="hobby" value="sailing" ' . (in_array("sailing", $array) ? 'checked="checked"' : "") . ' >';
            $output .=  '<label class="form-check-label" for="inlineRadio1">sailing</label>';
            $output .=  '</div>';

            $output .=  '<div class="form-check form-check-inline">';
            $output .=  '<input class="form-check-input" type="checkbox" name="hobby" class="hobby" value="judo" ' . (in_array("judo", $array) ? 'checked="checked"' : "") . ' >';
            $output .=  '<label class="form-check-label" for="inlineRadio1">judo</label>';
            $output .=  '</div>';

            $output .=  '</div>';

            $output .=  '<div class="row mt-5">';
            $output .=  '<div class="col text-center">';
            $output .=  '<input type="submit" value="submit" name="submit" id="updateSubmitStudentFormBtn" class="btn btn-dark  btn-lg">';
            $output .=  '</div>';
            $output .=  '</div>';
        }
        echo  $output;
    } else {
        echo   'RECORDS ARE NOT FOUND ';
    }
} else {

}
