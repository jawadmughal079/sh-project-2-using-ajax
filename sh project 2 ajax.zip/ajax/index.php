<?php


include 'header.php';

?>

<div class="container">
    <h1 class="text-center mt-4">Student Registration</h1>
    <h4 class="text-center">Fill out the form carefully for registration</h4>

    <form action="" method="post" enctype="multipart/form-data" id="myForm">
        <div class="row mt-3">
            <div class="col-6">
                <label for="firstName" class="form-label">First Name <span class="text-danger fw-bold text-center"> * </span></label>
                <input type="text" class="form-control" placeholder="First name" aria-label="First name" name="firstName" id="firstName" value="">

            </div>
            <div class="col-6">
                <label for="lastName" class="form-label">Last Name <span class="text-danger fw-bold text-center"> * </span></label>
                <input type="text" class="form-control" placeholder="Last name" aria-label="Last name" name="lastName" id="lastName" value="">

            </div>

        </div>
        <div class="row mt-3">
            <div class="col-md-6 ">
                <label for="email" class="form-label">Email <span class="text-danger fw-bold text-center"> * </span></label>

                <input type="text" class="form-control" placeholder="Enter Your Email" name="email" id="email" value="">

            </div>
            <div class="col-md-6">
                <label for="password" class="form-label">Password <span class="text-danger fw-bold text-center"> * </span></label>

                <input type="password" class="form-control" placeholder="Enter Passoword" name="password" id="password">

            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-6">
                <label for="degree" class="form-label">Degree <span class="text-danger fw-bold text-center"> * </span></label>

                <select class="form-select" name="degree" id="degree">
                    <option selected disabled value="">Choose Your Degree...</option>
                    <option value="bsse">Bsse</option>
                    <option value="bscs">bscs</option>
                </select>

            </div>
            <div class="col-md-6">
                <label for="fees" class="form-label">Fees <span class="text-danger fw-bold text-center"> * </span></label>

                <select id="fees" class="form-select" name="fees" value="">
                    <option selected disabled value="">Choose Your Fees...</option>
                    <option value="5000">5000</option>
                    <option value="10000">10000</option>
                </select>

            </div>

        </div>
        <div class="row mt-3">
            <div class="col-md-12">

                <label for="exampleInputEmail1" class="form-label mt-4">Gender <span class="text-danger fw-bold text-center"> * </span></label>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" class="gender" value="male">
                    <label class="form-check-label" for="inlineRadio1">Male</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" class="gender" value="female">
                    <label class="form-check-label" for="inlineRadio2">Female</label>
                </div>

            </div>
            <!-- <div class="col-md-6">
                <label for="formFile" class="form-label">Select Img </label>

                <input class="form-control" type="file" id="fileUpload" name="fileUpload">

            </div> -->
        </div>
        <div class="row mt-3 ">
            <div class="col-md mr-auto">

                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="cricket" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox1">cricket</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="swimming" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox2">swimming </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="cycling" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox1">cycling </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="tennis" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox2">tennis </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="boxing" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox1">boxing </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="shooting" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox2">shooting</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="sailing" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox1">sailing </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="judo" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox2">judo </label>
                </div>
            </div>
            <!-- <span id="hobbyError" class="text-danger fw-bold text-center text-capitalize"></span> -->
        </div>

        <div class="row mt-5">
            <div class="col text-center">
                <input type="submit" value="submit" name="submit" id="submitStudentForm" class="btn btn-dark  btn-lg">
            </div>
        </div>
</div>
</form>
<!-- show data -->
<div class="container">
    <div class="row mt-4 m-auto">
        <div class="col-10 ">
            <table class="table table-hover" id="studentShowTable">

            </table>
        </div>
    </div>
</div>
</div>




<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">Modal title</h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-hover" id="updateDateShow">

                </table>
            </div>

        </div>
    </div>
</div>

<!-- Modal -->
<!-- 
<div class="modal fade" id="exampleModal" data-bs-toggle="modal" data-bs-target="#exampleModal">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-hover" id="updateDateShow">

                </table>
            </div>
        </div>
    </div>
</div> -->




<!-- </div> -->
<!-- jquery cdn -->
<?php include 'footer.php'; ?>