<?php



include 'database.php';

if (isset($_POST['stundentId'])) {

    $stundentId = $_POST['stundentId'];


    $query = "DELETE FROM studentform WHERE stundentId = $stundentId";
    if (mysqli_query($connection, $query)) {
        echo 1;
    } else {
        echo 0;
    }
} else {
    header('location:index.php');
}
