<?php 



include 'database.php';
// WE FETCH THE DATA FROM THE OBJECT 
 $firstName  = $_POST['firstName'];
$lastName  = $_POST['lastName'];
$email  = $_POST['email'];
$password  = $_POST['password'];
$degree  = $_POST['degree'];
$fees = $_POST['fees'];
$gender  = $_POST['gender'];
// $fileUpload  = $_POST['fileUpload'];
$hobby  = $_POST['hobby'];

// $query =  "INSERT into studentform (firstName,lastName,email,password,degree,fees,gender,fileUpload,hobby) values('$firstName','$lastName','$email','$password','$degree','$fees','$gender','$fileUpload','$hobby')";
$query =  "INSERT into studentform (firstName,lastName,email,password,degree,fees,gender,hobby) values('$firstName','$lastName','$email','$password','$degree','$fees','$gender','$hobby')";
// $query = "INSERT INTO sdata ( firstName, lastName, email) VALUES ('$firstName','$lastName','$email')";
$result = mysqli_query($connection,$query);

if($result)
{
    echo 1;
 
}
else
{
    echo 'query is failed '.mysqli_error($connection) . mysqli_errno($connection);
 
    echo  0;
}



?>