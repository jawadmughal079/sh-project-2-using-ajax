<?php

include 'database.php';
// echo $_POST['stundentId'];
// die();
if (isset($_POST['stundentId'])) {
    // WE FETCH THE DATA FROM THE OBJECT 
    $stundentId  = $_POST['stundentId'];
    $firstName  = $_POST['updateFirstName'];
    $lastName  = $_POST['updateLastName'];
    $email  = $_POST['updateEmail'];
    $degree  = $_POST['updateDegree'];
    $fees = $_POST['updateFees'];
    $gender  = $_POST['Updategender'];
    // $fileUpload  = $_POST['fileUpload'];
    $hobby  = $_POST['UpdateHobby'];


    $query = "UPDATE studentform SET firstName = '$firstName' ,lastName ='$lastName' ,email ='$email' ,degree ='$degree',fees = $fees ,gender = '$gender',hobby = '$hobby' WHERE stundentId = $stundentId ";

    $result = mysqli_query($connection, $query);

    if ($result) {
        echo 1;
    } else {
        echo 'query is failed ' . mysqli_error($connection) . mysqli_errno($connection);

        echo  0;
    }
} else {
    die('no data is fetch ');
}
