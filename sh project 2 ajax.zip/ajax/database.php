<?php 

define('host', 'localhost');
define('user', 'root');
define('password', '');
define('database', 'ajaxstudent');

$connection = mysqli_connect(host, user, password, database);

if (!$connection) {
    echo ' connection of database is failed ';
    die();
}
 


?>