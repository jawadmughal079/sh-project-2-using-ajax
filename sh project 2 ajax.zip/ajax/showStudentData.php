<?php
include 'database.php';
$query = 'SELECT * from studentform';
$result = mysqli_query($connection, $query);


$output = '';
if (mysqli_num_rows($result) > 0) {


    //  // <th scope="col">Images</th>
    //     <td>{$rows["fileUpload"]}</td>
    $output .= '<div class="container">
        <div class="row mt-4 m-auto">
            <div class="col-10 ">
                <table class="table table-hover" >
                    <thead>
                        <tr>
                            <th scope="col">Student Id </th>
                            <th scope="col">First Name</th>
                            <th scope="col">last Name</th>
                            <th scope="col">Email</th>
                            <th scope="col">Degree</th>
                            <th scope="col">Fees</th>
                            <th scope="col">Gender</th>
                           
                            <th scope="col">Delete</th>
                            <th scope="col">Edit</th>

                        </tr>
                    </thead>
                    <tbody>';
    while ($rows = mysqli_fetch_assoc($result)) {
        $output .= "
                        <tr>
                            <td>{$rows["stundentId"]}</td>
                            <td>{$rows["firstName"]}</td>
                            <td>{$rows["lastName"]}</td>
                            <td>{$rows["email"]}</td>
                            <td>{$rows["degree"]}</td>
                            <td>{$rows["fees"]}</td>
                            <td>{$rows["gender"]}</td>
                        
                            <td><button class='delete-btn btn btn-danger' data-id='{$rows["stundentId"]}'>Delete </button></td>
                    
                            <td><button  class='edit-btn btn btn-primary' data-eid='{$rows["stundentId"]}' data-bs-toggle='modal' data-bs-target='#staticBackdrop'>Edit </button></td>
                        </tr>";
    }


    $output .= '</tbody>
                </table>
            </div>
        </div>
    </div> ';

    echo $output;
} else {
    echo 'RECORDS ARE NOT FOUND ';
}
