<!-- Footer -->
<footer class="text-center text-lg-start bg-white text-muted">


  <!-- Section: Links  -->
  <section class="">
    <div class="container text-center text-md-start mt-5">
      <!-- Grid row -->
      <div class="row mt-3">
        <!-- Grid column -->
        <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
          <!-- Content -->
          <h6 class="text-uppercase fw-bold mb-4">
            <i class="fas fa-gem me-3 text-secondary"></i>Jawad Mughal
          </h6>
          <p>
            Here you can use rows and columns to organize your footer content. Lorem ipsum
            dolor sit amet, consectetur adipisicing elit.
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Products
          </h6>
          <p>
            <a href="index.php" class="text-reset">Register</a>
          </p>
          <p>
            <a href="#!" class="text-reset">React</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Vue</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Laravel</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">
            Useful links
          </h6>
          <p>
            <a href="#!" class="text-reset">Pricing</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Settings</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Orders</a>
          </p>
          <p>
            <a href="#!" class="text-reset">Help</a>
          </p>
        </div>
        <!-- Grid column -->

        <!-- Grid column -->
        <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
          <!-- Links -->
          <h6 class="text-uppercase fw-bold mb-4">Contact</h6>
          <p><i class="fas fa-home me-3 text-secondary"></i> New York, NY 10012, US</p>
          <p>
            <i class="fas fa-envelope me-3 text-secondary"></i>
            info@example.com
          </p>
          <p><i class="fas fa-phone me-3 text-secondary"></i> + 01 234 567 88</p>
          <p><i class="fas fa-print me-3 text-secondary"></i> + 01 234 567 89</p>
        </div>
        <!-- Grid column -->
      </div>
      <!-- Grid row -->
    </div>
  </section>
  <!-- Section: Links  -->

  <!-- Copyright -->
  <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.025);">
    © 2023 Copyright:
    <a class="text-reset fw-bold" href="#">Jawad Mughal.com</a>
  </div>
  <!-- Copyright -->
</footer>
<!-- Footer -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
<script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>


<script>
  // jquery start

  $(document).ready(function() {


    // this is use to show the data 

    // $('#loadData').on("click", function(event) {

    //     $.ajax({
    //         url: 'showStudentData.php',
    //         type: 'POST',
    //         success: function(data) {
    //             $('#studentShowTable').html(data);
    //         }
    //     });

    // });


    function loadData() {

      $.ajax({
        url: 'showStudentData.php',
        success: function(data) {
          $('#studentShowTable').html(data);
        }
      });
    }
    loadData();
    // now insert the data 

    $('#myForm').on("submit", function(event) {


      event.preventDefault(); // chnage the behaviour of the submit button using preventDefult()

      var firstName = $('#firstName').val();
      var lastName = $('#lastName').val();
      var email = $('#email').val();
      var password = $('#password').val();
      var degree = $('#degree').val();
      var fees = $('#fees').val();
      var gender = $('input[name="gender"]:checked').val();
      // var fileUpload = $('input[name="fileUpload"]').val();
      // console.log(fileUpload);
      var hobby = [];
      $("input[name=hobby]:checked").each(function() {
        hobby.push($(this).val());
      });
      hobby = hobby.toString();


      $.ajax({
        // url means kis path ma ja chexx perform karni ha
        url: 'insertStudent.php',
        type: 'POST',
        data: {
          firstName: firstName,
          lastName: lastName,
          email: email,
          password: password,
          degree: degree,
          fees: fees,
          gender: gender,
          // fileUpload: fileUpload,
          hobby: hobby

        },

        // at the end file return something to use this funciton is use for this 

        success: function(data) {

          //$('#studentShowTable').load(location.href + ' #studentShowTable')
          if (data == 1) {
            loadData();
            $('#myForm').trigger('reset');
            alert('record is submited');
          } else {
            alert('cannot save the records');
          }

        }

      });

    });


    // delete the data

    $(document).on("click", ".delete-btn", function() {
      if (confirm("Do you really want to delete this record ?")) {

        var id = $(this).data('id');

        $.ajax({
          url: 'deleteStudent.php',
          type: 'POST',
          data: {
            stundentId: id
          },
          success: function(data) {
            if (data == 1) {
              loadData();
              alert('records is deleted ');
            } else {
              alert('records is not deleted');
            }
          }
        })
      }
    });

    // show the data into model
    $(document).on("click", ".edit-btn", function() {
      // get the id we want to edit
      var editId = $(this).data('eid');
      // alert(editId);
      $.ajax({

        url: "editStudent.php",
        type: "POST",
        data: {
          stundentId: editId
        },
        success: function(data) {
          $('#staticBackdrop table').html(data);

        }


      });



    });


    // now update the query 
    $(document).on("click", "#updateSubmitStudentFormBtn", function() {

      var updateStundentId = $('#stundentId').val();
      // console.log(updateStundentId);
      // alert("my id is this " + updateStundentId);
      var updateFirstName = $('#updateFirstName').val();
      // alert("myname is " + updateFirstName);
      var updateLastName = $('#updateLastName').val();
      // alert("last name is this : " + updateLastName);
      var updateEmail = $('#updateEmail').val();
      // alert("email is this : " + updateEmail);
      var updateDegree = $('#updateDegree').val();
      // alert("degree is this : " + updateDegree);
      var updateFees = $('#updateFees').val();
      // alert("Fees is this : " + updateFees);
      var Updategender = $('input[name="gender"]:checked').val();
      // alert('gender is this : ' + Updategender);
      var UpdateHobby = [];
      $("input[name=hobby]:checked").each(function() {
        UpdateHobby.push($(this).val());
      });
      UpdateHobby = UpdateHobby.toString();
      // alert(UpdateHobby);

      $.ajax({


        url: "updateStudentData.php",
        type: "POST",
        data: {
          stundentId: updateStundentId,
          updateFirstName: updateFirstName,
          updateLastName: updateLastName,
          updateEmail: updateEmail,
          updateDegree: updateDegree,
          updateFees: updateFees,
          Updategender: Updategender,
          // fileUpload: fileUpload,
          UpdateHobby: UpdateHobby

        },
        success: function(data) {
          if (data == 1) {
            $('#staticBackdrop').modal('toggle');
            alert('records is updated ');
            // $('#staticBackdrop').show();
            loadData();
          } else {
            alert('no records is updated ');
          }
        }



      });

    });

  });
</script>

</body>

</html>