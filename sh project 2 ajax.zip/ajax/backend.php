<?php


echo $_POST['sName'];
die();

if (isset($_POST['sName'])) {
    echo $sName = mysqli_real_escape_string($connection, $_POST['sName']);

    echo $sEmail = mysqli_real_escape_string($connection, $_POST['sEmail']);
    die();
    $sPassword = mysqli_real_escape_string($connection, $_POST['sPassword']);
    $sAddress = mysqli_real_escape_string($connection, $_POST['sAddress']);
    $sCity = mysqli_real_escape_string($connection, $_POST['sCity']);

    if ($name == NULL || $sEmail == NULL || $sPassword == NULL || $sAddress == NULL || $sCity == NULL) {
        $res = [
            'status' => 422,
            'messege' => 'ALL FIELDS ARE MANDATORY'
        ];
        echo json_encode($res);
        return false;
    }

    $query = "INSERT INTO studentrecords( sName,sPassword, sAddress, sCity, sEmail) VALUES ('$sName' , '$sEmail' , '$sPassword' , '$sAddress' ,'$sCity')";

    $result = mysqli_query($connection, $query);

    if ($result) {
        $res = [
            'status' => 422,
            'messege' => 'STUDENT ARE CREATED '
        ];
        echo json_encode($res);
        return false;
    } else {
        $res = [
            'status' => 500,
            'messege' => 'STUDENT ARE NOT CREATED  '
        ];
        echo json_encode($res);
        return false;
    }
}
