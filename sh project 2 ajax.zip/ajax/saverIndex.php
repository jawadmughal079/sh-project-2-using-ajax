<?php


include 'header.php';

?>


<div class="container">
    <h1 class="text-center mt-4">Student Registration</h1>
    <h4 class="text-center">Fill out the form carefully for registration</h4>

    <form action="" method="post" enctype="multipart/form-data" id="myForm">
        <div class="row mt-3">
            <div class="col-6">
                <label for="firstName" class="form-label">First Name <span class="text-danger fw-bold text-center"> * </span></label>
                <input type="text" class="form-control" placeholder="First name" aria-label="First name" name="firstName" id="firstName" value="">

            </div>
            <div class="col-6">
                <label for="lastName" class="form-label">Last Name <span class="text-danger fw-bold text-center"> * </span></label>
                <input type="text" class="form-control" placeholder="Last name" aria-label="Last name" name="lastName" id="lastName" value="">

            </div>

        </div>
        <div class="row mt-3">
            <div class="col-md-6 ">
                <label for="email" class="form-label">Email <span class="text-danger fw-bold text-center"> * </span></label>

                <input type="text" class="form-control" placeholder="Enter Your Email" name="email" id="email" value="">

            </div>
            <div class="col-md-6">
                <label for="password" class="form-label">Password <span class="text-danger fw-bold text-center"> * </span></label>

                <input type="password" class="form-control" placeholder="Enter Passoword" name="password" id="password">

            </div>
        </div>
        <div class="row mt-3">
            <div class="col-md-6">
                <label for="degree" class="form-label">Degree <span class="text-danger fw-bold text-center"> * </span></label>

                <select class="form-select" name="degree" id="degree">
                    <option selected disabled value="">Choose Your Degree...</option>
                    <option value="bsse">Bsse</option>
                    <option value="bscs">bscs</option>
                </select>

            </div>
            <div class="col-md-6">
                <label for="fees" class="form-label">Fees <span class="text-danger fw-bold text-center"> * </span></label>

                <select id="fees" class="form-select" name="fees" value="">
                    <option selected disabled value="">Choose Your Fees...</option>
                    <option value="5000">5000</option>
                    <option value="10000">10000</option>
                </select>

            </div>

        </div>
        <div class="row mt-3">
            <div class="col-md-6">

                <label for="exampleInputEmail1" class="form-label mt-4">Gender <span class="text-danger fw-bold text-center"> * </span></label>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" class="gender" value="male">
                    <label class="form-check-label" for="inlineRadio1">Male</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="radio" name="gender" class="gender" value="female">
                    <label class="form-check-label" for="inlineRadio2">Female</label>
                </div>

            </div>
            <div class="col-md-6">
                <label for="formFile" class="form-label">Select Img </label>

                <input class="form-control" type="file" id="fileUpload" name="fileUpload">

            </div>
        </div>
        <div class="row mt-3 ">
            <div class="col-md mr-auto">

                ` <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="cricket" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox1">cricket</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="swimming" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox2">swimming </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="cycling" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox1">cycling </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="tennis" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox2">tennis </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="boxing" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox1">boxing </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="shooting" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox2">shooting</label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="sailing" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox1">sailing </label>
                </div>
                <div class="form-check form-check-inline">
                    <input class="form-check-input" type="checkbox" class="hobby" value="judo" name="hobby">
                    <label class="form-check-label" for="inlineCheckbox2">judo </label>
                </div>`
            </div>
            <!-- <span id="hobbyError" class="text-danger fw-bold text-center text-capitalize"></span> -->
        </div>
        <div>
            <div class="row mt-5">
                <div class="col text-center">
                    <input type="submit" value="submit" name="submit" id="submitStudentForm" class="btn btn-dark  btn-lg">
                </div>
            </div>
        </div>
    </form>
</div>
<!-- jquery cdn -->
<script src="https://code.jquery.com/jquery-3.6.3.min.js" integrity="sha256-pvPw+upLPUjgMXY0G+8O0xUf+/Im1MZjXxxgOcBQBXU=" crossorigin="anonymous"></script>


<script>
    // jquery start

    $(document).ready(function() {


        // make a selector for when user click on the id = submitStudentForm

        $('#submitStudentForm').on("click", function(event) {

            event.preventDefault(); // chnage the behaviour of the submit button using preventDefult()




            var firstName = $('#firstName').val();
            var lastName = $('#lastName').val();
            var email = $('#email').val();
            var password = $('#password').val();
            var degree = $('#degree').val();
            var fees = $('#fees').val();
            var gender = $('input[name="gender"]:checked').val();
            var fileUpload = $('input[name="fileUpload"]').val();
            console.log(fileUpload);
            var hobby = [];
            $("input[name=hobby]:checked").each(function() {
                hobby.push($(this).val());
            });
            hobby = hobby.toString();






            $.ajax({
                // url means kis path ma ja chexx perform karni ha
                url: 'insertStudent.php',
                type: 'POST',
                data: {
                    firstName: firstName,
                    lastName: lastName,
                    email: email,
                    password: password,
                    degree: degree,
                    fees: fees,
                    gender: gender,
                    fileUpload: fileUpload,
                    hobby: hobby

                },
                // contentType : multipart/form-data,
                // at the end file return something to use this funciton is use for this 

                success: function(data) {
                    
                }



            });

        });

    });
</script>

<?php include 'footer.php'; ?>